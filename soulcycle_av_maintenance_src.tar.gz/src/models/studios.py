"""
Studio model for SoulCycle AV Maintenance System.
"""

from .db import db, BaseModel
from sqlalchemy.orm import relationship


class Studio(BaseModel):
    """
    Studio model representing SoulCycle studio locations.
    """
    __tablename__ = 'studios'
    
    # Basic Information
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    address = db.Column(db.Text)
    city = db.Column(db.String(50))
    state = db.Column(db.String(20))
    zip_code = db.Column(db.String(10))
    phone = db.Column(db.String(20))
    
    # Status and Capacity
    status = db.Column(db.String(20), default='active', nullable=False)
    capacity = db.Column(db.Integer)
    classes_per_day = db.Column(db.Integer)
    operating_hours = db.Column(db.String(50))
    
    # Management Information
    manager_name = db.Column(db.String(100))
    manager_email = db.Column(db.String(100))
    manager_phone = db.Column(db.String(20))
    
    # Relationships
    equipment = relationship('Equipment', back_populates='studio', lazy='dynamic')
    maintenance_tasks = relationship('MaintenanceTask', back_populates='studio', lazy='dynamic')
    alerts = relationship('Alert', back_populates='studio', lazy='dynamic')
    reports = relationship('Report', back_populates='studio', lazy='dynamic')
    
    def __repr__(self):
        return f'<Studio {self.name}>'
    
    def to_dict(self):
        """Convert studio to dictionary with additional computed fields."""
        data = super().to_dict()
        data.update({
            'equipment_count': self.equipment.count(),
            'active_alerts': self.alerts.filter_by(status='active').count(),
            'pending_maintenance': self.maintenance_tasks.filter_by(status='pending').count()
        })
        return data
    
    @property
    def is_active(self):
        """Check if studio is active."""
        return self.status == 'active'
    
    @classmethod
    def get_active_studios(cls):
        """Get all active studios."""
        return cls.query.filter_by(status='active').all()
    
    @classmethod
    def search_by_location(cls, location):
        """Search studios by location."""
        return cls.query.filter(cls.location.ilike(f'%{location}%')).all()
    
    def get_equipment_by_type(self, equipment_type):
        """Get equipment of specific type in this studio."""
        return self.equipment.filter_by(type=equipment_type).all()
    
    def get_overdue_maintenance(self):
        """Get overdue maintenance tasks for this studio."""
        from datetime import datetime
        return self.maintenance_tasks.filter(
            MaintenanceTask.due_date < datetime.utcnow(),
            MaintenanceTask.status != 'completed'
        ).all()
    
    def get_critical_alerts(self):
        """Get critical alerts for this studio."""
        return self.alerts.filter_by(level='critical', status='active').all()

