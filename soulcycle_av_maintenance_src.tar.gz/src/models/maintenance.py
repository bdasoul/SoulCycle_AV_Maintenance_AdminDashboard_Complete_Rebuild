"""
Maintenance model for SoulCycle AV Maintenance System.
"""

from .db import db, BaseModel
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta


class MaintenanceTask(BaseModel):
    """
    MaintenanceTask model representing maintenance tasks for AV equipment.
    """
    __tablename__ = 'maintenance_tasks'
    
    # Task Information
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    task_type = db.Column(db.String(50), nullable=False)  # preventive, corrective, emergency
    priority = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    
    # Associations
    studio_id = db.Column(db.Integer, db.ForeignKey('studios.id'), nullable=False)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    
    # Scheduling
    due_date = db.Column(db.DateTime, nullable=False)
    scheduled_date = db.Column(db.DateTime)
    estimated_duration = db.Column(db.Integer)  # minutes
    
    # Status and Progress
    status = db.Column(db.String(20), default='pending', nullable=False)  # pending, scheduled, in_progress, completed, cancelled
    completion_percentage = db.Column(db.Integer, default=0)
    
    # Assignment
    assigned_technician = db.Column(db.String(100))
    technician_notes = db.Column(db.Text)
    
    # Completion Information
    completed_date = db.Column(db.DateTime)
    actual_duration = db.Column(db.Integer)  # minutes
    completion_notes = db.Column(db.Text)
    
    # Cost Tracking
    estimated_cost = db.Column(db.Numeric(10, 2))
    actual_cost = db.Column(db.Numeric(10, 2))
    parts_cost = db.Column(db.Numeric(10, 2))
    labor_cost = db.Column(db.Numeric(10, 2))
    
    # Safety and Requirements
    safety_requirements = db.Column(db.Text)
    required_tools = db.Column(db.Text)  # JSON string
    required_parts = db.Column(db.Text)  # JSON string
    
    # Relationships
    studio = relationship('Studio', back_populates='maintenance_tasks')
    equipment = relationship('Equipment', back_populates='maintenance_tasks')
    alerts = relationship('Alert', back_populates='maintenance_task', lazy='dynamic')
    
    def __repr__(self):
        return f'<MaintenanceTask {self.title} ({self.status})>'
    
    def to_dict(self):
        """Convert maintenance task to dictionary with additional computed fields."""
        data = super().to_dict()
        data.update({
            'studio_name': self.studio.name if self.studio else None,
            'equipment_name': self.equipment.name if self.equipment else None,
            'equipment_type': self.equipment.type if self.equipment else None,
            'is_overdue': self.is_overdue,
            'days_overdue': self.days_overdue,
            'days_until_due': self.days_until_due,
            'duration_status': self.duration_status,
            'cost_variance': self.cost_variance
        })
        return data
    
    @property
    def is_overdue(self):
        """Check if task is overdue."""
        return self.due_date < datetime.utcnow() and self.status not in ['completed', 'cancelled']
    
    @property
    def days_overdue(self):
        """Get number of days overdue."""
        if not self.is_overdue:
            return 0
        return (datetime.utcnow() - self.due_date).days
    
    @property
    def days_until_due(self):
        """Get number of days until due."""
        if self.status in ['completed', 'cancelled']:
            return None
        return (self.due_date - datetime.utcnow()).days
    
    @property
    def duration_status(self):
        """Get duration performance status."""
        if not self.actual_duration or not self.estimated_duration:
            return 'unknown'
        
        variance = (self.actual_duration - self.estimated_duration) / self.estimated_duration
        
        if variance <= -0.1:
            return 'under_estimate'
        elif variance >= 0.2:
            return 'over_estimate'
        else:
            return 'on_estimate'
    
    @property
    def cost_variance(self):
        """Get cost variance percentage."""
        if not self.actual_cost or not self.estimated_cost:
            return None
        
        return ((self.actual_cost - self.estimated_cost) / self.estimated_cost) * 100
    
    def start_task(self, technician_name=None):
        """Start the maintenance task."""
        self.status = 'in_progress'
        self.scheduled_date = datetime.utcnow()
        if technician_name:
            self.assigned_technician = technician_name
        self.save()
        
        # Create alert for task start
        from .alerts import Alert
        alert = Alert(
            maintenance_task_id=self.id,
            studio_id=self.studio_id,
            equipment_id=self.equipment_id,
            level='info',
            message=f'Maintenance task "{self.title}" has been started',
            alert_type='task_started'
        )
        alert.save()
    
    def complete_task(self, completion_notes=None, actual_duration=None, actual_cost=None):
        """Complete the maintenance task."""
        self.status = 'completed'
        self.completed_date = datetime.utcnow()
        self.completion_percentage = 100
        
        if completion_notes:
            self.completion_notes = completion_notes
        if actual_duration:
            self.actual_duration = actual_duration
        if actual_cost:
            self.actual_cost = actual_cost
        
        # Update equipment last maintenance date
        if self.equipment:
            self.equipment.last_maintenance = self.completed_date
            self.equipment.calculate_next_maintenance()
            self.equipment.save()
        
        self.save()
        
        # Create completion alert
        from .alerts import Alert
        alert = Alert(
            maintenance_task_id=self.id,
            studio_id=self.studio_id,
            equipment_id=self.equipment_id,
            level='info',
            message=f'Maintenance task "{self.title}" has been completed',
            alert_type='task_completed'
        )
        alert.save()
    
    def cancel_task(self, reason=None):
        """Cancel the maintenance task."""
        self.status = 'cancelled'
        if reason:
            self.technician_notes = f"Cancelled: {reason}"
        self.save()
    
    def escalate_priority(self):
        """Escalate task priority."""
        priority_levels = ['low', 'medium', 'high', 'critical']
        current_index = priority_levels.index(self.priority)
        
        if current_index < len(priority_levels) - 1:
            self.priority = priority_levels[current_index + 1]
            self.save()
            
            # Create escalation alert
            from .alerts import Alert
            alert = Alert(
                maintenance_task_id=self.id,
                studio_id=self.studio_id,
                equipment_id=self.equipment_id,
                level='warning',
                message=f'Maintenance task "{self.title}" priority escalated to {self.priority}',
                alert_type='priority_escalation'
            )
            alert.save()
    
    @classmethod
    def get_overdue_tasks(cls):
        """Get all overdue maintenance tasks."""
        return cls.query.filter(
            cls.due_date < datetime.utcnow(),
            cls.status.notin_(['completed', 'cancelled'])
        ).all()
    
    @classmethod
    def get_upcoming_tasks(cls, days=7):
        """Get tasks due within specified days."""
        cutoff_date = datetime.utcnow() + timedelta(days=days)
        return cls.query.filter(
            cls.due_date <= cutoff_date,
            cls.due_date >= datetime.utcnow(),
            cls.status == 'pending'
        ).all()
    
    @classmethod
    def get_by_technician(cls, technician_name):
        """Get tasks assigned to specific technician."""
        return cls.query.filter_by(
            assigned_technician=technician_name,
            status='in_progress'
        ).all()
    
    @classmethod
    def get_by_priority(cls, priority):
        """Get tasks by priority level."""
        return cls.query.filter_by(
            priority=priority,
            status='pending'
        ).all()
    
    @classmethod
    def get_completion_stats(cls, studio_id=None, start_date=None, end_date=None):
        """Get completion statistics for tasks."""
        query = cls.query
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        if start_date:
            query = query.filter(cls.created_at >= start_date)
        
        if end_date:
            query = query.filter(cls.created_at <= end_date)
        
        total_tasks = query.count()
        completed_tasks = query.filter_by(status='completed').count()
        overdue_tasks = query.filter(
            cls.due_date < datetime.utcnow(),
            cls.status.notin_(['completed', 'cancelled'])
        ).count()
        
        completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        return {
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'overdue_tasks': overdue_tasks,
            'completion_rate': round(completion_rate, 2)
        }

