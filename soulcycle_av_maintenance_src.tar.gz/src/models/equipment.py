"""
Equipment model for SoulCycle AV Maintenance System.
"""

from .db import db, BaseModel
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta


class Equipment(BaseModel):
    """
    Equipment model representing AV equipment in SoulCycle studios.
    """
    __tablename__ = 'equipment'
    
    # Basic Information
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # amplifier, microphone, dsp, power
    manufacturer = db.Column(db.String(50))
    model = db.Column(db.String(50))
    serial_number = db.Column(db.String(100), unique=True)
    
    # Studio Association
    studio_id = db.Column(db.Integer, db.ForeignKey('studios.id'), nullable=False)
    location_in_studio = db.Column(db.String(100))
    
    # Status and Specifications
    status = db.Column(db.String(20), default='active', nullable=False)
    is_critical = db.Column(db.Boolean, default=False)
    specifications = db.Column(db.Text)  # JSON string for flexible specs
    
    # Maintenance Information
    maintenance_interval = db.Column(db.Integer, default=90)  # days
    last_maintenance = db.Column(db.DateTime)
    next_maintenance = db.Column(db.DateTime)
    maintenance_notes = db.Column(db.Text)
    
    # Usage Tracking
    operating_hours = db.Column(db.Integer, default=0)
    power_cycles = db.Column(db.Integer, default=0)
    failure_count = db.Column(db.Integer, default=0)
    
    # Purchase and Warranty
    purchase_date = db.Column(db.Date)
    installation_date = db.Column(db.Date)
    warranty_expiry = db.Column(db.Date)
    cost = db.Column(db.Numeric(10, 2))
    
    # Relationships
    studio = relationship('Studio', back_populates='equipment')
    maintenance_tasks = relationship('MaintenanceTask', back_populates='equipment', lazy='dynamic')
    alerts = relationship('Alert', back_populates='equipment', lazy='dynamic')
    
    def __repr__(self):
        return f'<Equipment {self.name} ({self.type})>'
    
    def to_dict(self):
        """Convert equipment to dictionary with additional computed fields."""
        data = super().to_dict()
        data.update({
            'studio_name': self.studio.name if self.studio else None,
            'maintenance_status': self.maintenance_status,
            'days_until_maintenance': self.days_until_maintenance,
            'warranty_status': self.warranty_status,
            'active_alerts': self.alerts.filter_by(status='active').count()
        })
        return data
    
    @property
    def maintenance_status(self):
        """Get current maintenance status."""
        if not self.next_maintenance:
            return 'unknown'
        
        days_until = (self.next_maintenance - datetime.utcnow()).days
        
        if days_until < 0:
            return 'overdue'
        elif days_until <= 7:
            return 'due_soon'
        elif days_until <= 30:
            return 'upcoming'
        else:
            return 'current'
    
    @property
    def days_until_maintenance(self):
        """Get days until next maintenance."""
        if not self.next_maintenance:
            return None
        return (self.next_maintenance - datetime.utcnow()).days
    
    @property
    def warranty_status(self):
        """Get warranty status."""
        if not self.warranty_expiry:
            return 'unknown'
        
        days_until_expiry = (self.warranty_expiry - datetime.utcnow().date()).days
        
        if days_until_expiry < 0:
            return 'expired'
        elif days_until_expiry <= 30:
            return 'expiring_soon'
        elif days_until_expiry <= 90:
            return 'expiring'
        else:
            return 'valid'
    
    @property
    def is_active(self):
        """Check if equipment is active."""
        return self.status == 'active'
    
    def calculate_next_maintenance(self):
        """Calculate next maintenance date based on interval."""
        if self.last_maintenance:
            self.next_maintenance = self.last_maintenance + timedelta(days=self.maintenance_interval)
        else:
            # If no previous maintenance, schedule based on installation date or now
            base_date = self.installation_date or datetime.utcnow().date()
            self.next_maintenance = datetime.combine(base_date, datetime.min.time()) + timedelta(days=self.maintenance_interval)
        
        return self.next_maintenance
    
    def update_operating_hours(self, hours):
        """Update operating hours and check if maintenance is needed."""
        self.operating_hours += hours
        
        # Check if usage-based maintenance is needed (every 1000 hours)
        if self.operating_hours % 1000 == 0:
            self.schedule_maintenance('usage_based')
    
    def record_failure(self, description=None):
        """Record equipment failure."""
        self.failure_count += 1
        
        # Create critical alert for failure
        from .alerts import Alert
        alert = Alert(
            equipment_id=self.id,
            studio_id=self.studio_id,
            level='critical',
            message=f'Equipment failure recorded for {self.name}. Description: {description or "No description provided"}',
            alert_type='equipment_failure'
        )
        alert.save()
    
    def schedule_maintenance(self, task_type='preventive'):
        """Schedule maintenance task for this equipment."""
        from .maintenance import MaintenanceTask
        
        task = MaintenanceTask(
            studio_id=self.studio_id,
            equipment_id=self.id,
            task_type=task_type,
            due_date=self.next_maintenance or datetime.utcnow() + timedelta(days=7),
            status='pending',
            description=f'{task_type.title()} maintenance for {self.name}'
        )
        task.save()
        return task
    
    @classmethod
    def get_by_type(cls, equipment_type):
        """Get all equipment of specific type."""
        return cls.query.filter_by(type=equipment_type, status='active').all()
    
    @classmethod
    def get_critical_equipment(cls):
        """Get all critical equipment."""
        return cls.query.filter_by(is_critical=True, status='active').all()
    
    @classmethod
    def get_overdue_maintenance(cls):
        """Get equipment with overdue maintenance."""
        return cls.query.filter(
            cls.next_maintenance < datetime.utcnow(),
            cls.status == 'active'
        ).all()
    
    @classmethod
    def get_expiring_warranties(cls, days=90):
        """Get equipment with warranties expiring within specified days."""
        cutoff_date = datetime.utcnow().date() + timedelta(days=days)
        return cls.query.filter(
            cls.warranty_expiry <= cutoff_date,
            cls.warranty_expiry >= datetime.utcnow().date(),
            cls.status == 'active'
        ).all()

