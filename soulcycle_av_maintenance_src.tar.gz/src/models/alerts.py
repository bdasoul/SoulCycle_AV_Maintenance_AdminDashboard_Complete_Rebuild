"""
Alert model for SoulCycle AV Maintenance System.
"""

from .db import db, BaseModel
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta


class Alert(BaseModel):
    """
    Alert model representing system alerts and notifications.
    """
    __tablename__ = 'alerts'
    
    # Alert Information
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    level = db.Column(db.String(20), nullable=False)  # info, warning, error, critical
    alert_type = db.Column(db.String(50), nullable=False)  # maintenance_due, equipment_failure, etc.
    
    # Associations
    studio_id = db.Column(db.Integer, db.ForeignKey('studios.id'))
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    maintenance_task_id = db.Column(db.Integer, db.ForeignKey('maintenance_tasks.id'))
    
    # Status and Timing
    status = db.Column(db.String(20), default='active', nullable=False)  # active, acknowledged, resolved, dismissed
    priority_score = db.Column(db.Integer, default=0)  # For sorting/filtering
    
    # Resolution Information
    acknowledged_at = db.Column(db.DateTime)
    acknowledged_by = db.Column(db.String(100))
    resolved_at = db.Column(db.DateTime)
    resolved_by = db.Column(db.String(100))
    resolution_notes = db.Column(db.Text)
    
    # Notification Settings
    email_sent = db.Column(db.Boolean, default=False)
    sms_sent = db.Column(db.Boolean, default=False)
    notification_count = db.Column(db.Integer, default=0)
    last_notification = db.Column(db.DateTime)
    
    # Auto-resolution
    auto_resolve_at = db.Column(db.DateTime)
    escalation_level = db.Column(db.Integer, default=0)
    
    # Relationships
    studio = relationship('Studio', back_populates='alerts')
    equipment = relationship('Equipment', back_populates='alerts')
    maintenance_task = relationship('MaintenanceTask', back_populates='alerts')
    
    def __repr__(self):
        return f'<Alert {self.title} ({self.level})>'
    
    def to_dict(self):
        """Convert alert to dictionary with additional computed fields."""
        data = super().to_dict()
        data.update({
            'studio_name': self.studio.name if self.studio else None,
            'equipment_name': self.equipment.name if self.equipment else None,
            'equipment_type': self.equipment.type if self.equipment else None,
            'task_title': self.maintenance_task.title if self.maintenance_task else None,
            'age_hours': self.age_hours,
            'is_overdue': self.is_overdue,
            'severity_score': self.severity_score
        })
        return data
    
    @property
    def age_hours(self):
        """Get age of alert in hours."""
        return int((datetime.utcnow() - self.created_at).total_seconds() / 3600)
    
    @property
    def is_overdue(self):
        """Check if alert response is overdue based on level."""
        response_times = {
            'critical': 1,  # 1 hour
            'error': 4,     # 4 hours
            'warning': 24,  # 24 hours
            'info': 72      # 72 hours
        }
        
        max_hours = response_times.get(self.level, 72)
        return self.age_hours > max_hours and self.status == 'active'
    
    @property
    def severity_score(self):
        """Calculate severity score for prioritization."""
        level_scores = {
            'critical': 100,
            'error': 75,
            'warning': 50,
            'info': 25
        }
        
        base_score = level_scores.get(self.level, 0)
        
        # Add urgency based on age
        urgency_bonus = min(self.age_hours, 48)  # Max 48 points for age
        
        # Add equipment criticality bonus
        criticality_bonus = 25 if (self.equipment and self.equipment.is_critical) else 0
        
        return base_score + urgency_bonus + criticality_bonus
    
    def acknowledge(self, acknowledged_by=None):
        """Acknowledge the alert."""
        self.status = 'acknowledged'
        self.acknowledged_at = datetime.utcnow()
        if acknowledged_by:
            self.acknowledged_by = acknowledged_by
        self.save()
    
    def resolve(self, resolved_by=None, resolution_notes=None):
        """Resolve the alert."""
        self.status = 'resolved'
        self.resolved_at = datetime.utcnow()
        if resolved_by:
            self.resolved_by = resolved_by
        if resolution_notes:
            self.resolution_notes = resolution_notes
        self.save()
    
    def dismiss(self):
        """Dismiss the alert without resolution."""
        self.status = 'dismissed'
        self.save()
    
    def escalate(self):
        """Escalate the alert to higher priority."""
        level_escalation = {
            'info': 'warning',
            'warning': 'error',
            'error': 'critical'
        }
        
        if self.level in level_escalation:
            self.level = level_escalation[self.level]
            self.escalation_level += 1
            self.save()
            
            # Create escalation notification
            self.send_notification(f"Alert escalated to {self.level}")
    
    def send_notification(self, custom_message=None):
        """Send notification for this alert."""
        self.notification_count += 1
        self.last_notification = datetime.utcnow()
        
        # In a real implementation, this would integrate with email/SMS services
        # For now, we'll just log the notification
        message = custom_message or self.message
        print(f"NOTIFICATION: {self.level.upper()} - {self.title}: {message}")
        
        self.save()
    
    def auto_resolve_check(self):
        """Check if alert should be auto-resolved."""
        if self.auto_resolve_at and datetime.utcnow() >= self.auto_resolve_at:
            self.resolve(resolved_by='system', resolution_notes='Auto-resolved')
    
    @classmethod
    def create_maintenance_due_alert(cls, equipment):
        """Create alert for maintenance due."""
        days_until = equipment.days_until_maintenance
        
        if days_until is None:
            return None
        
        if days_until <= 0:
            level = 'error'
            title = f'Maintenance Overdue: {equipment.name}'
            message = f'Maintenance for {equipment.name} is {abs(days_until)} days overdue'
        elif days_until <= 3:
            level = 'warning'
            title = f'Maintenance Due Soon: {equipment.name}'
            message = f'Maintenance for {equipment.name} is due in {days_until} days'
        elif days_until <= 7:
            level = 'info'
            title = f'Maintenance Upcoming: {equipment.name}'
            message = f'Maintenance for {equipment.name} is due in {days_until} days'
        else:
            return None  # No alert needed yet
        
        alert = cls(
            title=title,
            message=message,
            level=level,
            alert_type='maintenance_due',
            studio_id=equipment.studio_id,
            equipment_id=equipment.id
        )
        alert.save()
        return alert
    
    @classmethod
    def create_equipment_failure_alert(cls, equipment, failure_description):
        """Create alert for equipment failure."""
        alert = cls(
            title=f'Equipment Failure: {equipment.name}',
            message=f'Equipment failure reported for {equipment.name}. Description: {failure_description}',
            level='critical',
            alert_type='equipment_failure',
            studio_id=equipment.studio_id,
            equipment_id=equipment.id
        )
        alert.save()
        return alert
    
    @classmethod
    def create_warranty_expiry_alert(cls, equipment):
        """Create alert for warranty expiry."""
        if not equipment.warranty_expiry:
            return None
        
        days_until_expiry = (equipment.warranty_expiry - datetime.utcnow().date()).days
        
        if days_until_expiry <= 30:
            level = 'warning'
        elif days_until_expiry <= 90:
            level = 'info'
        else:
            return None  # No alert needed yet
        
        alert = cls(
            title=f'Warranty Expiring: {equipment.name}',
            message=f'Warranty for {equipment.name} expires in {days_until_expiry} days on {equipment.warranty_expiry}',
            level=level,
            alert_type='warranty_expiry',
            studio_id=equipment.studio_id,
            equipment_id=equipment.id
        )
        alert.save()
        return alert
    
    @classmethod
    def get_active_alerts(cls, studio_id=None, level=None):
        """Get active alerts with optional filtering."""
        query = cls.query.filter_by(status='active')
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        if level:
            query = query.filter_by(level=level)
        
        return query.order_by(cls.created_at.desc()).all()
    
    @classmethod
    def get_critical_alerts(cls):
        """Get all critical active alerts."""
        return cls.query.filter_by(level='critical', status='active').all()
    
    @classmethod
    def get_overdue_alerts(cls):
        """Get alerts that are overdue for response."""
        alerts = cls.get_active_alerts()
        return [alert for alert in alerts if alert.is_overdue]
    
    @classmethod
    def get_alert_statistics(cls, studio_id=None, days=30):
        """Get alert statistics for dashboard."""
        start_date = datetime.utcnow() - timedelta(days=days)
        query = cls.query.filter(cls.created_at >= start_date)
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        total_alerts = query.count()
        active_alerts = query.filter_by(status='active').count()
        critical_alerts = query.filter_by(level='critical').count()
        resolved_alerts = query.filter_by(status='resolved').count()
        
        resolution_rate = (resolved_alerts / total_alerts * 100) if total_alerts > 0 else 0
        
        return {
            'total_alerts': total_alerts,
            'active_alerts': active_alerts,
            'critical_alerts': critical_alerts,
            'resolved_alerts': resolved_alerts,
            'resolution_rate': round(resolution_rate, 2)
        }
    
    @classmethod
    def cleanup_old_alerts(cls, days=90):
        """Clean up old resolved/dismissed alerts."""
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        old_alerts = cls.query.filter(
            cls.status.in_(['resolved', 'dismissed']),
            cls.updated_at < cutoff_date
        ).all()
        
        for alert in old_alerts:
            alert.delete()
        
        return len(old_alerts)

