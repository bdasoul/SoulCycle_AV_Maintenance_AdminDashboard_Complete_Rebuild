"""
Report model for SoulCycle AV Maintenance System.
"""

from .db import db, BaseModel
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta
import json


class Report(BaseModel):
    """
    Report model representing generated maintenance reports.
    """
    __tablename__ = 'reports'
    
    # Report Information
    title = db.Column(db.String(200), nullable=False)
    report_type = db.Column(db.String(50), nullable=False)  # maintenance_summary, equipment_status, etc.
    description = db.Column(db.Text)
    
    # Associations
    studio_id = db.Column(db.Integer, db.ForeignKey('studios.id'))
    generated_by = db.Column(db.String(100))
    
    # Report Data
    summary = db.Column(db.Text)  # JSON string with report summary
    data = db.Column(db.Text)     # JSON string with detailed report data
    parameters = db.Column(db.Text)  # JSON string with generation parameters
    
    # Timing and Status
    generated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    period_start = db.Column(db.DateTime)
    period_end = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='completed', nullable=False)  # generating, completed, failed
    
    # File Information
    file_path = db.Column(db.String(500))
    file_format = db.Column(db.String(20))  # pdf, csv, html, json
    file_size = db.Column(db.Integer)
    
    # Access and Sharing
    is_public = db.Column(db.Boolean, default=False)
    access_count = db.Column(db.Integer, default=0)
    last_accessed = db.Column(db.DateTime)
    
    # Relationships
    studio = relationship('Studio', back_populates='reports')
    
    def __repr__(self):
        return f'<Report {self.title} ({self.report_type})>'
    
    def to_dict(self):
        """Convert report to dictionary with additional computed fields."""
        data = super().to_dict()
        data.update({
            'studio_name': self.studio.name if self.studio else None,
            'summary_data': self.get_summary_data(),
            'parameters_data': self.get_parameters_data(),
            'age_days': self.age_days,
            'file_size_mb': self.file_size_mb
        })
        return data
    
    @property
    def age_days(self):
        """Get age of report in days."""
        return (datetime.utcnow() - self.generated_at).days
    
    @property
    def file_size_mb(self):
        """Get file size in MB."""
        return round(self.file_size / (1024 * 1024), 2) if self.file_size else 0
    
    def get_summary_data(self):
        """Get parsed summary data."""
        if self.summary:
            try:
                return json.loads(self.summary)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def set_summary_data(self, data):
        """Set summary data as JSON."""
        self.summary = json.dumps(data, default=str)
    
    def get_report_data(self):
        """Get parsed report data."""
        if self.data:
            try:
                return json.loads(self.data)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def set_report_data(self, data):
        """Set report data as JSON."""
        self.data = json.dumps(data, default=str)
    
    def get_parameters_data(self):
        """Get parsed parameters data."""
        if self.parameters:
            try:
                return json.loads(self.parameters)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def set_parameters_data(self, data):
        """Set parameters data as JSON."""
        self.parameters = json.dumps(data, default=str)
    
    def record_access(self):
        """Record report access."""
        self.access_count += 1
        self.last_accessed = datetime.utcnow()
        self.save()
    
    def generate_maintenance_summary(self, studio_id=None, start_date=None, end_date=None):
        """Generate maintenance summary report."""
        from .maintenance import MaintenanceTask
        from .equipment import Equipment
        from .alerts import Alert
        
        # Set default date range if not provided
        if not end_date:
            end_date = datetime.utcnow()
        if not start_date:
            start_date = end_date - timedelta(days=30)
        
        self.period_start = start_date
        self.period_end = end_date
        
        # Query data
        task_query = MaintenanceTask.query.filter(
            MaintenanceTask.created_at >= start_date,
            MaintenanceTask.created_at <= end_date
        )
        
        if studio_id:
            task_query = task_query.filter_by(studio_id=studio_id)
            self.studio_id = studio_id
        
        tasks = task_query.all()
        
        # Calculate summary statistics
        total_tasks = len(tasks)
        completed_tasks = len([t for t in tasks if t.status == 'completed'])
        overdue_tasks = len([t for t in tasks if t.is_overdue])
        
        completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        # Equipment statistics
        equipment_query = Equipment.query.filter_by(status='active')
        if studio_id:
            equipment_query = equipment_query.filter_by(studio_id=studio_id)
        
        equipment_list = equipment_query.all()
        total_equipment = len(equipment_list)
        critical_equipment = len([e for e in equipment_list if e.is_critical])
        
        # Alert statistics
        alert_query = Alert.query.filter(
            Alert.created_at >= start_date,
            Alert.created_at <= end_date
        )
        
        if studio_id:
            alert_query = alert_query.filter_by(studio_id=studio_id)
        
        alerts = alert_query.all()
        total_alerts = len(alerts)
        critical_alerts = len([a for a in alerts if a.level == 'critical'])
        
        # Set summary data
        summary_data = {
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'overdue_tasks': overdue_tasks,
            'completion_rate': round(completion_rate, 2),
            'total_equipment': total_equipment,
            'critical_equipment': critical_equipment,
            'total_alerts': total_alerts,
            'critical_alerts': critical_alerts
        }
        
        self.set_summary_data(summary_data)
        
        # Set detailed report data
        report_data = {
            'tasks': [task.to_dict() for task in tasks],
            'equipment': [eq.to_dict() for eq in equipment_list],
            'alerts': [alert.to_dict() for alert in alerts]
        }
        
        self.set_report_data(report_data)
        
        # Set parameters
        parameters = {
            'studio_id': studio_id,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
            'generated_by': self.generated_by
        }
        
        self.set_parameters_data(parameters)
        
        self.status = 'completed'
        self.save()
        
        return self
    
    def generate_equipment_status_report(self, studio_id=None, equipment_type=None):
        """Generate equipment status report."""
        from .equipment import Equipment
        
        # Query equipment
        query = Equipment.query.filter_by(status='active')
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
            self.studio_id = studio_id
        
        if equipment_type:
            query = query.filter_by(type=equipment_type)
        
        equipment_list = query.all()
        
        # Calculate statistics
        total_equipment = len(equipment_list)
        critical_equipment = len([e for e in equipment_list if e.is_critical])
        overdue_maintenance = len([e for e in equipment_list if e.maintenance_status == 'overdue'])
        due_soon = len([e for e in equipment_list if e.maintenance_status == 'due_soon'])
        
        # Group by type
        by_type = {}
        for equipment in equipment_list:
            if equipment.type not in by_type:
                by_type[equipment.type] = 0
            by_type[equipment.type] += 1
        
        # Set summary data
        summary_data = {
            'total_equipment': total_equipment,
            'critical_equipment': critical_equipment,
            'overdue_maintenance': overdue_maintenance,
            'due_soon_maintenance': due_soon,
            'by_type': by_type
        }
        
        self.set_summary_data(summary_data)
        
        # Set detailed report data
        report_data = {
            'equipment': [eq.to_dict() for eq in equipment_list]
        }
        
        self.set_report_data(report_data)
        
        # Set parameters
        parameters = {
            'studio_id': studio_id,
            'equipment_type': equipment_type,
            'generated_by': self.generated_by
        }
        
        self.set_parameters_data(parameters)
        
        self.status = 'completed'
        self.save()
        
        return self
    
    @classmethod
    def create_maintenance_summary(cls, studio_id=None, start_date=None, end_date=None, generated_by=None):
        """Create and generate maintenance summary report."""
        studio_name = ""
        if studio_id:
            from .studios import Studio
            studio = Studio.get_by_id(studio_id)
            studio_name = f" - {studio.name}" if studio else ""
        
        report = cls(
            title=f'Maintenance Summary Report{studio_name}',
            report_type='maintenance_summary',
            description='Comprehensive maintenance activity summary',
            studio_id=studio_id,
            generated_by=generated_by,
            status='generating'
        )
        report.save()
        
        # Generate the report
        report.generate_maintenance_summary(studio_id, start_date, end_date)
        
        return report
    
    @classmethod
    def create_equipment_status(cls, studio_id=None, equipment_type=None, generated_by=None):
        """Create and generate equipment status report."""
        studio_name = ""
        if studio_id:
            from .studios import Studio
            studio = Studio.get_by_id(studio_id)
            studio_name = f" - {studio.name}" if studio else ""
        
        type_filter = f" ({equipment_type})" if equipment_type else ""
        
        report = cls(
            title=f'Equipment Status Report{studio_name}{type_filter}',
            report_type='equipment_status',
            description='Current status of all equipment',
            studio_id=studio_id,
            generated_by=generated_by,
            status='generating'
        )
        report.save()
        
        # Generate the report
        report.generate_equipment_status_report(studio_id, equipment_type)
        
        return report
    
    @classmethod
    def get_recent_reports(cls, limit=10, studio_id=None):
        """Get recent reports."""
        query = cls.query.order_by(cls.generated_at.desc())
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        return query.limit(limit).all()
    
    @classmethod
    def get_by_type(cls, report_type, studio_id=None):
        """Get reports by type."""
        query = cls.query.filter_by(report_type=report_type)
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        return query.order_by(cls.generated_at.desc()).all()
    
    @classmethod
    def cleanup_old_reports(cls, days=180):
        """Clean up old reports."""
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        old_reports = cls.query.filter(cls.generated_at < cutoff_date).all()
        
        for report in old_reports:
            # In a real implementation, you'd also delete the associated files
            report.delete()
        
        return len(old_reports)

