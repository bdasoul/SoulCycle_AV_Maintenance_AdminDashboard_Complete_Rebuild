"""
Main Flask application for SoulCycle AV Maintenance System.
"""

from flask import Flask, jsonify
from flask_cors import CORS
from src.models.db import init_db
from src.routes import (
    studios_bp,
    equipment_bp,
    maintenance_bp,
    alerts_bp,
    reports_bp
)


def create_app():
    """
    Application factory pattern for creating Flask app.
    """
    app = Flask(__name__)
    
    # Configure CORS
    CORS(app, resources={
        r"/api/*": {
            "origins": ["http://localhost:3000", "http://localhost:5173"],
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })
    
    # Configure database
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///maintenance.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = 'soulcycle-av-maintenance-secret-key'
    
    # Initialize database
    init_db(app)
    
    # Register blueprints with /api prefix
    app.register_blueprint(studios_bp, url_prefix='/api/studios')
    app.register_blueprint(equipment_bp, url_prefix='/api/equipment')
    app.register_blueprint(maintenance_bp, url_prefix='/api/maintenance')
    app.register_blueprint(alerts_bp, url_prefix='/api/alerts')
    app.register_blueprint(reports_bp, url_prefix='/api/reports')
    
    # Root endpoint
    @app.route('/')
    def index():
        """Root endpoint with API information."""
        return jsonify({
            'message': 'SoulCycle AV Maintenance System API',
            'version': '1.0.0',
            'endpoints': {
                'studios': '/api/studios',
                'equipment': '/api/equipment',
                'maintenance': '/api/maintenance',
                'alerts': '/api/alerts',
                'reports': '/api/reports'
            },
            'documentation': '/api/docs'
        })
    
    # API documentation endpoint
    @app.route('/api')
    @app.route('/api/docs')
    def api_docs():
        """API documentation endpoint."""
        return jsonify({
            'title': 'SoulCycle AV Maintenance System API',
            'version': '1.0.0',
            'description': 'RESTful API for managing preventative maintenance workflows for SoulCycle AV Studios',
            'endpoints': {
                'studios': {
                    'base_url': '/api/studios',
                    'methods': ['GET', 'POST', 'PUT', 'DELETE'],
                    'description': 'Manage SoulCycle studio locations and information'
                },
                'equipment': {
                    'base_url': '/api/equipment',
                    'methods': ['GET', 'POST', 'PUT', 'DELETE'],
                    'description': 'Manage AV equipment across all studios'
                },
                'maintenance': {
                    'base_url': '/api/maintenance',
                    'methods': ['GET', 'POST', 'PUT', 'DELETE'],
                    'description': 'Manage maintenance tasks and schedules'
                },
                'alerts': {
                    'base_url': '/api/alerts',
                    'methods': ['GET', 'POST', 'PUT', 'DELETE'],
                    'description': 'Manage system alerts and notifications'
                },
                'reports': {
                    'base_url': '/api/reports',
                    'methods': ['GET', 'POST', 'PUT', 'DELETE'],
                    'description': 'Generate and manage maintenance reports'
                }
            },
            'common_query_parameters': {
                'limit': 'Limit number of results',
                'offset': 'Offset for pagination',
                'studio_id': 'Filter by studio ID',
                'status': 'Filter by status'
            },
            'response_format': {
                'success': 'Boolean indicating request success',
                'data': 'Response data (array or object)',
                'count': 'Number of items returned (for lists)',
                'message': 'Success or error message',
                'error': 'Error description (on failure)'
            }
        })
    
    # Health check endpoint
    @app.route('/health')
    def health_check():
        """Health check endpoint for monitoring."""
        return jsonify({
            'status': 'healthy',
            'timestamp': '2024-01-01T00:00:00Z',
            'version': '1.0.0',
            'database': 'connected'
        })
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors."""
        return jsonify({
            'success': False,
            'error': 'Endpoint not found',
            'message': 'The requested resource was not found on this server'
        }), 404
    
    @app.errorhandler(405)
    def method_not_allowed(error):
        """Handle 405 errors."""
        return jsonify({
            'success': False,
            'error': 'Method not allowed',
            'message': 'The method is not allowed for the requested URL'
        }), 405
    
    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors."""
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'message': 'An unexpected error occurred on the server'
        }), 500
    
    return app


# Create app instance
app = create_app()


if __name__ == '__main__':
    # Run the application
    print("Starting SoulCycle AV Maintenance System...")
    print("API Documentation: http://localhost:5000/api/docs")
    print("Health Check: http://localhost:5000/health")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )

