"""
Reports API routes for SoulCycle AV Maintenance System.
"""

from flask import Blueprint, request, jsonify
from src.models import db, Report, Studio
from datetime import datetime, timedelta

reports_bp = Blueprint('reports', __name__)


@reports_bp.route('/', methods=['GET'])
def get_reports():
    """
    Get all reports with optional filtering.
    
    Query Parameters:
        studio_id: Filter by studio ID
        report_type: Filter by report type
        generated_by: Filter by who generated the report
        days: Filter reports from last N days
        limit: Limit number of results
        offset: Offset for pagination
    """
    try:
        # Get query parameters
        studio_id = request.args.get('studio_id', type=int)
        report_type = request.args.get('report_type')
        generated_by = request.args.get('generated_by')
        days = request.args.get('days', type=int)
        limit = request.args.get('limit', type=int, default=50)
        offset = request.args.get('offset', type=int, default=0)
        
        # Build query
        query = Report.query
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        if report_type:
            query = query.filter_by(report_type=report_type)
        
        if generated_by:
            query = query.filter_by(generated_by=generated_by)
        
        if days:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            query = query.filter(Report.generated_at >= cutoff_date)
        
        # Order by generation date (descending)
        query = query.order_by(Report.generated_at.desc())
        
        # Apply pagination
        reports = query.offset(offset).limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': [report.to_dict() for report in reports],
            'count': len(reports)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/', methods=['POST'])
def create_report():
    """
    Create and generate a new report.
    
    Required fields: title, report_type
    Optional fields: description, studio_id, generated_by, period_start, period_end
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['title', 'report_type']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validate report type
        valid_types = ['maintenance_summary', 'equipment_status', 'alert_summary', 'custom']
        if data['report_type'] not in valid_types:
            return jsonify({
                'success': False,
                'error': f'Invalid report type. Must be one of: {", ".join(valid_types)}'
            }), 400
        
        # Validate studio if provided
        if data.get('studio_id'):
            studio = Studio.get_by_id(data['studio_id'])
            if not studio:
                return jsonify({
                    'success': False,
                    'error': 'Studio not found'
                }), 404
        
        # Parse date fields if provided
        period_start = None
        period_end = None
        
        if data.get('period_start'):
            try:
                period_start = datetime.fromisoformat(data['period_start'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid period_start format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        if data.get('period_end'):
            try:
                period_end = datetime.fromisoformat(data['period_end'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid period_end format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        # Create report based on type
        if data['report_type'] == 'maintenance_summary':
            report = Report.create_maintenance_summary(
                studio_id=data.get('studio_id'),
                start_date=period_start,
                end_date=period_end,
                generated_by=data.get('generated_by')
            )
        elif data['report_type'] == 'equipment_status':
            equipment_type = data.get('equipment_type')
            report = Report.create_equipment_status(
                studio_id=data.get('studio_id'),
                equipment_type=equipment_type,
                generated_by=data.get('generated_by')
            )
        else:
            # Create basic report for custom types
            report = Report(
                title=data['title'],
                report_type=data['report_type'],
                description=data.get('description'),
                studio_id=data.get('studio_id'),
                generated_by=data.get('generated_by'),
                period_start=period_start,
                period_end=period_end,
                status='completed'
            )
            report.save()
        
        return jsonify({
            'success': True,
            'data': report.to_dict(),
            'message': 'Report created successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/<int:report_id>', methods=['GET'])
def get_report(report_id):
    """
    Get a specific report by ID.
    """
    try:
        report = Report.get_by_id(report_id)
        
        if not report:
            return jsonify({
                'success': False,
                'error': 'Report not found'
            }), 404
        
        # Record access
        report.record_access()
        
        return jsonify({
            'success': True,
            'data': report.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/<int:report_id>', methods=['PUT'])
def update_report(report_id):
    """
    Update a specific report.
    """
    try:
        report = Report.get_by_id(report_id)
        
        if not report:
            return jsonify({
                'success': False,
                'error': 'Report not found'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Update fields if provided
        updatable_fields = [
            'title', 'description', 'is_public'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(report, field, data[field])
        
        report.save()
        
        return jsonify({
            'success': True,
            'data': report.to_dict(),
            'message': 'Report updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/<int:report_id>', methods=['DELETE'])
def delete_report(report_id):
    """
    Delete a specific report.
    """
    try:
        report = Report.get_by_id(report_id)
        
        if not report:
            return jsonify({
                'success': False,
                'error': 'Report not found'
            }), 404
        
        report.delete()
        
        return jsonify({
            'success': True,
            'message': 'Report deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/<int:report_id>/data', methods=['GET'])
def get_report_data(report_id):
    """
    Get the detailed data for a specific report.
    """
    try:
        report = Report.get_by_id(report_id)
        
        if not report:
            return jsonify({
                'success': False,
                'error': 'Report not found'
            }), 404
        
        # Record access
        report.record_access()
        
        return jsonify({
            'success': True,
            'data': {
                'report_info': {
                    'id': report.id,
                    'title': report.title,
                    'report_type': report.report_type,
                    'generated_at': report.generated_at.isoformat(),
                    'period_start': report.period_start.isoformat() if report.period_start else None,
                    'period_end': report.period_end.isoformat() if report.period_end else None
                },
                'summary': report.get_summary_data(),
                'detailed_data': report.get_report_data(),
                'parameters': report.get_parameters_data()
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/maintenance-summary', methods=['POST'])
def generate_maintenance_summary():
    """
    Generate a maintenance summary report.
    
    Optional fields: studio_id, start_date, end_date, generated_by
    """
    try:
        data = request.get_json() or {}
        
        studio_id = data.get('studio_id')
        generated_by = data.get('generated_by')
        
        # Parse date fields
        start_date = None
        end_date = None
        
        if data.get('start_date'):
            try:
                start_date = datetime.fromisoformat(data['start_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid start_date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        if data.get('end_date'):
            try:
                end_date = datetime.fromisoformat(data['end_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid end_date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        # Validate studio if provided
        if studio_id:
            studio = Studio.get_by_id(studio_id)
            if not studio:
                return jsonify({
                    'success': False,
                    'error': 'Studio not found'
                }), 404
        
        # Generate report
        report = Report.create_maintenance_summary(
            studio_id=studio_id,
            start_date=start_date,
            end_date=end_date,
            generated_by=generated_by
        )
        
        return jsonify({
            'success': True,
            'data': report.to_dict(),
            'message': 'Maintenance summary report generated successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/equipment-status', methods=['POST'])
def generate_equipment_status():
    """
    Generate an equipment status report.
    
    Optional fields: studio_id, equipment_type, generated_by
    """
    try:
        data = request.get_json() or {}
        
        studio_id = data.get('studio_id')
        equipment_type = data.get('equipment_type')
        generated_by = data.get('generated_by')
        
        # Validate studio if provided
        if studio_id:
            studio = Studio.get_by_id(studio_id)
            if not studio:
                return jsonify({
                    'success': False,
                    'error': 'Studio not found'
                }), 404
        
        # Validate equipment type if provided
        if equipment_type:
            valid_types = ['amplifier', 'microphone', 'dsp', 'power', 'mixer', 'speaker', 'other']
            if equipment_type not in valid_types:
                return jsonify({
                    'success': False,
                    'error': f'Invalid equipment type. Must be one of: {", ".join(valid_types)}'
                }), 400
        
        # Generate report
        report = Report.create_equipment_status(
            studio_id=studio_id,
            equipment_type=equipment_type,
            generated_by=generated_by
        )
        
        return jsonify({
            'success': True,
            'data': report.to_dict(),
            'message': 'Equipment status report generated successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/types', methods=['GET'])
def get_report_types():
    """
    Get all available report types.
    """
    try:
        types = [
            {
                'type': 'maintenance_summary',
                'name': 'Maintenance Summary',
                'description': 'Comprehensive overview of maintenance activities'
            },
            {
                'type': 'equipment_status',
                'name': 'Equipment Status',
                'description': 'Current status and health of all equipment'
            },
            {
                'type': 'alert_summary',
                'name': 'Alert Summary',
                'description': 'Summary of alerts and notifications'
            },
            {
                'type': 'custom',
                'name': 'Custom Report',
                'description': 'User-defined custom report'
            }
        ]
        
        return jsonify({
            'success': True,
            'data': types
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/recent', methods=['GET'])
def get_recent_reports():
    """
    Get recent reports.
    """
    try:
        limit = request.args.get('limit', 10, type=int)
        studio_id = request.args.get('studio_id', type=int)
        
        reports = Report.get_recent_reports(limit, studio_id)
        
        return jsonify({
            'success': True,
            'data': [report.to_dict() for report in reports],
            'count': len(reports)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/by-type/<report_type>', methods=['GET'])
def get_reports_by_type(report_type):
    """
    Get reports by type.
    """
    try:
        studio_id = request.args.get('studio_id', type=int)
        
        reports = Report.get_by_type(report_type, studio_id)
        
        return jsonify({
            'success': True,
            'data': [report.to_dict() for report in reports],
            'count': len(reports),
            'report_type': report_type
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/stats', methods=['GET'])
def get_report_stats():
    """
    Get report generation statistics.
    """
    try:
        studio_id = request.args.get('studio_id', type=int)
        days = request.args.get('days', 30, type=int)
        
        # Base query
        query = Report.query
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        # Total reports
        total_reports = query.count()
        
        # Recent reports
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        recent_reports = query.filter(Report.generated_at >= cutoff_date).count()
        
        # Reports by type
        by_type = {}
        for report_type in ['maintenance_summary', 'equipment_status', 'alert_summary', 'custom']:
            count = query.filter_by(report_type=report_type).count()
            by_type[report_type] = count
        
        # Reports by status
        by_status = {}
        for status in ['generating', 'completed', 'failed']:
            count = query.filter_by(status=status).count()
            by_status[status] = count
        
        # Most accessed reports
        popular_reports = query.order_by(Report.access_count.desc()).limit(5).all()
        
        return jsonify({
            'success': True,
            'data': {
                'total_reports': total_reports,
                'recent_reports': recent_reports,
                'by_type': by_type,
                'by_status': by_status,
                'popular_reports': [
                    {
                        'id': report.id,
                        'title': report.title,
                        'access_count': report.access_count
                    } for report in popular_reports
                ],
                'period_days': days
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/cleanup', methods=['POST'])
def cleanup_old_reports():
    """
    Clean up old reports.
    """
    try:
        data = request.get_json() or {}
        days = data.get('days', 180)
        
        if not isinstance(days, int) or days < 1:
            return jsonify({
                'success': False,
                'error': 'Days must be a positive integer'
            }), 400
        
        deleted_count = Report.cleanup_old_reports(days)
        
        return jsonify({
            'success': True,
            'message': f'Cleaned up {deleted_count} old reports',
            'deleted_count': deleted_count,
            'days_threshold': days
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@reports_bp.route('/export/<int:report_id>', methods=['GET'])
def export_report(report_id):
    """
    Export a report in various formats.
    """
    try:
        report = Report.get_by_id(report_id)
        
        if not report:
            return jsonify({
                'success': False,
                'error': 'Report not found'
            }), 404
        
        export_format = request.args.get('format', 'json').lower()
        
        if export_format not in ['json', 'csv', 'html']:
            return jsonify({
                'success': False,
                'error': 'Invalid format. Must be one of: json, csv, html'
            }), 400
        
        # Record access
        report.record_access()
        
        # Get report data
        report_data = {
            'report_info': {
                'id': report.id,
                'title': report.title,
                'report_type': report.report_type,
                'generated_at': report.generated_at.isoformat(),
                'studio_name': report.studio.name if report.studio else 'All Studios'
            },
            'summary': report.get_summary_data(),
            'data': report.get_report_data()
        }
        
        if export_format == 'json':
            return jsonify({
                'success': True,
                'data': report_data,
                'format': 'json'
            })
        
        elif export_format == 'csv':
            # For CSV, we'll return the data in a format suitable for CSV conversion
            # In a real implementation, you'd generate actual CSV content
            return jsonify({
                'success': True,
                'message': 'CSV export format not fully implemented in this demo',
                'data': report_data,
                'format': 'csv'
            })
        
        elif export_format == 'html':
            # For HTML, we'll return the data in a format suitable for HTML rendering
            # In a real implementation, you'd generate actual HTML content
            return jsonify({
                'success': True,
                'message': 'HTML export format not fully implemented in this demo',
                'data': report_data,
                'format': 'html'
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

