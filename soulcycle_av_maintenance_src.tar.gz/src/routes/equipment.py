"""
Equipment API routes for SoulCycle AV Maintenance System.
"""

from flask import Blueprint, request, jsonify
from src.models import db, Equipment, Studio
from datetime import datetime, timedelta
import json

equipment_bp = Blueprint('equipment', __name__)


@equipment_bp.route('/', methods=['GET'])
def get_equipment():
    """
    Get all equipment with optional filtering.
    
    Query Parameters:
        studio_id: Filter by studio ID
        type: Filter by equipment type
        status: Filter by status (active, inactive, maintenance)
        critical: Filter critical equipment only (true/false)
        maintenance_status: Filter by maintenance status (current, due_soon, overdue)
        limit: Limit number of results
        offset: Offset for pagination
    """
    try:
        # Get query parameters
        studio_id = request.args.get('studio_id', type=int)
        equipment_type = request.args.get('type')
        status = request.args.get('status')
        critical_only = request.args.get('critical', 'false').lower() == 'true'
        maintenance_status = request.args.get('maintenance_status')
        limit = request.args.get('limit', type=int)
        offset = request.args.get('offset', type=int, default=0)
        
        # Build query
        query = Equipment.query
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        if equipment_type:
            query = query.filter_by(type=equipment_type)
        
        if status:
            query = query.filter_by(status=status)
        
        if critical_only:
            query = query.filter_by(is_critical=True)
        
        equipment_list = query.offset(offset).all()
        
        # Filter by maintenance status if specified
        if maintenance_status:
            equipment_list = [eq for eq in equipment_list if eq.maintenance_status == maintenance_status]
        
        # Apply limit after filtering
        if limit:
            equipment_list = equipment_list[:limit]
        
        return jsonify({
            'success': True,
            'data': [equipment.to_dict() for equipment in equipment_list],
            'count': len(equipment_list)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/', methods=['POST'])
def create_equipment():
    """
    Create new equipment.
    
    Required fields: name, type, studio_id
    Optional fields: manufacturer, model, serial_number, location_in_studio,
                    is_critical, specifications, maintenance_interval,
                    purchase_date, installation_date, warranty_expiry, cost
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['name', 'type', 'studio_id']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validate studio exists
        studio = Studio.get_by_id(data['studio_id'])
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        # Validate equipment type
        valid_types = ['amplifier', 'microphone', 'dsp', 'power', 'mixer', 'speaker', 'other']
        if data['type'] not in valid_types:
            return jsonify({
                'success': False,
                'error': f'Invalid equipment type. Must be one of: {", ".join(valid_types)}'
            }), 400
        
        # Check if serial number is unique (if provided)
        if data.get('serial_number'):
            existing_equipment = Equipment.query.filter_by(serial_number=data['serial_number']).first()
            if existing_equipment:
                return jsonify({
                    'success': False,
                    'error': 'Equipment with this serial number already exists'
                }), 409
        
        # Parse dates if provided
        purchase_date = None
        installation_date = None
        warranty_expiry = None
        
        if data.get('purchase_date'):
            try:
                purchase_date = datetime.strptime(data['purchase_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid purchase_date format. Use YYYY-MM-DD'
                }), 400
        
        if data.get('installation_date'):
            try:
                installation_date = datetime.strptime(data['installation_date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid installation_date format. Use YYYY-MM-DD'
                }), 400
        
        if data.get('warranty_expiry'):
            try:
                warranty_expiry = datetime.strptime(data['warranty_expiry'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid warranty_expiry format. Use YYYY-MM-DD'
                }), 400
        
        # Create new equipment
        equipment = Equipment(
            name=data['name'],
            type=data['type'],
            studio_id=data['studio_id'],
            manufacturer=data.get('manufacturer'),
            model=data.get('model'),
            serial_number=data.get('serial_number'),
            location_in_studio=data.get('location_in_studio'),
            is_critical=data.get('is_critical', False),
            specifications=json.dumps(data.get('specifications', {})) if data.get('specifications') else None,
            maintenance_interval=data.get('maintenance_interval', 90),
            purchase_date=purchase_date,
            installation_date=installation_date,
            warranty_expiry=warranty_expiry,
            cost=data.get('cost'),
            status=data.get('status', 'active')
        )
        
        # Calculate next maintenance date
        equipment.calculate_next_maintenance()
        
        equipment.save()
        
        return jsonify({
            'success': True,
            'data': equipment.to_dict(),
            'message': 'Equipment created successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>', methods=['GET'])
def get_equipment_by_id(equipment_id):
    """
    Get specific equipment by ID.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': equipment.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>', methods=['PUT'])
def update_equipment(equipment_id):
    """
    Update specific equipment.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Update fields if provided
        updatable_fields = [
            'name', 'type', 'manufacturer', 'model', 'serial_number',
            'location_in_studio', 'is_critical', 'maintenance_interval',
            'cost', 'status', 'operating_hours', 'power_cycles'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(equipment, field, data[field])
        
        # Handle specifications separately (JSON field)
        if 'specifications' in data:
            equipment.specifications = json.dumps(data['specifications'])
        
        # Handle date fields
        date_fields = ['purchase_date', 'installation_date', 'warranty_expiry']
        for field in date_fields:
            if field in data and data[field]:
                try:
                    date_value = datetime.strptime(data[field], '%Y-%m-%d').date()
                    setattr(equipment, field, date_value)
                except ValueError:
                    return jsonify({
                        'success': False,
                        'error': f'Invalid {field} format. Use YYYY-MM-DD'
                    }), 400
        
        # Recalculate next maintenance if interval changed
        if 'maintenance_interval' in data:
            equipment.calculate_next_maintenance()
        
        equipment.save()
        
        return jsonify({
            'success': True,
            'data': equipment.to_dict(),
            'message': 'Equipment updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>', methods=['DELETE'])
def delete_equipment(equipment_id):
    """
    Delete specific equipment.
    Note: This will also delete all associated maintenance tasks and alerts.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        # Check if equipment has pending maintenance tasks
        pending_tasks = equipment.maintenance_tasks.filter_by(status='pending').count()
        if pending_tasks > 0:
            return jsonify({
                'success': False,
                'error': f'Cannot delete equipment with {pending_tasks} pending maintenance tasks. Complete or cancel tasks first.'
            }), 409
        
        equipment.delete()
        
        return jsonify({
            'success': True,
            'message': 'Equipment deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>/maintenance', methods=['GET'])
def get_equipment_maintenance(equipment_id):
    """
    Get maintenance tasks for specific equipment.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        status = request.args.get('status')
        
        if status:
            tasks = equipment.maintenance_tasks.filter_by(status=status).all()
        else:
            tasks = equipment.maintenance_tasks.all()
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>/alerts', methods=['GET'])
def get_equipment_alerts(equipment_id):
    """
    Get alerts for specific equipment.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        status = request.args.get('status', 'active')
        level = request.args.get('level')
        
        query = equipment.alerts.filter_by(status=status)
        
        if level:
            query = query.filter_by(level=level)
        
        alerts = query.all()
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>/schedule-maintenance', methods=['POST'])
def schedule_equipment_maintenance(equipment_id):
    """
    Schedule maintenance for specific equipment.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        data = request.get_json()
        task_type = data.get('task_type', 'preventive')
        
        task = equipment.schedule_maintenance(task_type)
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': 'Maintenance scheduled successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>/record-failure', methods=['POST'])
def record_equipment_failure(equipment_id):
    """
    Record equipment failure.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        data = request.get_json()
        description = data.get('description', 'No description provided')
        
        equipment.record_failure(description)
        
        return jsonify({
            'success': True,
            'message': 'Equipment failure recorded successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/<int:equipment_id>/update-hours', methods=['POST'])
def update_equipment_hours(equipment_id):
    """
    Update equipment operating hours.
    """
    try:
        equipment = Equipment.get_by_id(equipment_id)
        
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        data = request.get_json()
        
        if 'hours' not in data:
            return jsonify({
                'success': False,
                'error': 'Hours parameter is required'
            }), 400
        
        hours = data['hours']
        
        if not isinstance(hours, (int, float)) or hours < 0:
            return jsonify({
                'success': False,
                'error': 'Hours must be a positive number'
            }), 400
        
        equipment.update_operating_hours(hours)
        
        return jsonify({
            'success': True,
            'data': equipment.to_dict(),
            'message': 'Operating hours updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/types', methods=['GET'])
def get_equipment_types():
    """
    Get all available equipment types.
    """
    try:
        types = ['amplifier', 'microphone', 'dsp', 'power', 'mixer', 'speaker', 'other']
        
        return jsonify({
            'success': True,
            'data': types
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/critical', methods=['GET'])
def get_critical_equipment():
    """
    Get all critical equipment.
    """
    try:
        equipment_list = Equipment.get_critical_equipment()
        
        return jsonify({
            'success': True,
            'data': [equipment.to_dict() for equipment in equipment_list],
            'count': len(equipment_list)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/overdue-maintenance', methods=['GET'])
def get_overdue_maintenance():
    """
    Get equipment with overdue maintenance.
    """
    try:
        equipment_list = Equipment.get_overdue_maintenance()
        
        return jsonify({
            'success': True,
            'data': [equipment.to_dict() for equipment in equipment_list],
            'count': len(equipment_list)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/expiring-warranties', methods=['GET'])
def get_expiring_warranties():
    """
    Get equipment with expiring warranties.
    """
    try:
        days = request.args.get('days', 90, type=int)
        equipment_list = Equipment.get_expiring_warranties(days)
        
        return jsonify({
            'success': True,
            'data': [equipment.to_dict() for equipment in equipment_list],
            'count': len(equipment_list),
            'days_threshold': days
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/stats', methods=['GET'])
def get_equipment_stats():
    """
    Get equipment statistics.
    """
    try:
        studio_id = request.args.get('studio_id', type=int)
        
        # Base query
        query = Equipment.query.filter_by(status='active')
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        equipment_list = query.all()
        
        # Calculate statistics
        total_equipment = len(equipment_list)
        critical_equipment = len([eq for eq in equipment_list if eq.is_critical])
        
        # Group by type
        by_type = {}
        for equipment in equipment_list:
            if equipment.type not in by_type:
                by_type[equipment.type] = 0
            by_type[equipment.type] += 1
        
        # Group by maintenance status
        by_maintenance_status = {}
        for equipment in equipment_list:
            status = equipment.maintenance_status
            if status not in by_maintenance_status:
                by_maintenance_status[status] = 0
            by_maintenance_status[status] += 1
        
        # Group by warranty status
        by_warranty_status = {}
        for equipment in equipment_list:
            status = equipment.warranty_status
            if status not in by_warranty_status:
                by_warranty_status[status] = 0
            by_warranty_status[status] += 1
        
        return jsonify({
            'success': True,
            'data': {
                'total_equipment': total_equipment,
                'critical_equipment': critical_equipment,
                'by_type': by_type,
                'by_maintenance_status': by_maintenance_status,
                'by_warranty_status': by_warranty_status
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@equipment_bp.route('/search', methods=['GET'])
def search_equipment():
    """
    Search equipment by various criteria.
    """
    try:
        query_param = request.args.get('q', '').strip()
        
        if not query_param:
            return jsonify({
                'success': False,
                'error': 'Search query parameter "q" is required'
            }), 400
        
        # Search in name, manufacturer, model, and serial number
        equipment_list = Equipment.query.filter(
            db.or_(
                Equipment.name.ilike(f'%{query_param}%'),
                Equipment.manufacturer.ilike(f'%{query_param}%'),
                Equipment.model.ilike(f'%{query_param}%'),
                Equipment.serial_number.ilike(f'%{query_param}%')
            )
        ).all()
        
        return jsonify({
            'success': True,
            'data': [equipment.to_dict() for equipment in equipment_list],
            'count': len(equipment_list),
            'query': query_param
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

