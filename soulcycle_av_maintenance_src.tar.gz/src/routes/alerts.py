"""
Alerts API routes for SoulCycle AV Maintenance System.
"""

from flask import Blueprint, request, jsonify
from src.models import db, Alert, Studio, Equipment, MaintenanceTask
from datetime import datetime, timedelta

alerts_bp = Blueprint('alerts', __name__)


@alerts_bp.route('/', methods=['GET'])
def get_alerts():
    """
    Get all alerts with optional filtering.
    
    Query Parameters:
        studio_id: Filter by studio ID
        equipment_id: Filter by equipment ID
        maintenance_task_id: Filter by maintenance task ID
        level: Filter by alert level (info, warning, error, critical)
        status: Filter by status (active, acknowledged, resolved, dismissed)
        alert_type: Filter by alert type
        overdue: Filter overdue alerts only (true/false)
        limit: Limit number of results
        offset: Offset for pagination
    """
    try:
        # Get query parameters
        studio_id = request.args.get('studio_id', type=int)
        equipment_id = request.args.get('equipment_id', type=int)
        maintenance_task_id = request.args.get('maintenance_task_id', type=int)
        level = request.args.get('level')
        status = request.args.get('status', 'active')
        alert_type = request.args.get('alert_type')
        overdue_only = request.args.get('overdue', 'false').lower() == 'true'
        limit = request.args.get('limit', type=int)
        offset = request.args.get('offset', type=int, default=0)
        
        # Build query
        query = Alert.query
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        if equipment_id:
            query = query.filter_by(equipment_id=equipment_id)
        
        if maintenance_task_id:
            query = query.filter_by(maintenance_task_id=maintenance_task_id)
        
        if level:
            query = query.filter_by(level=level)
        
        if status:
            query = query.filter_by(status=status)
        
        if alert_type:
            query = query.filter_by(alert_type=alert_type)
        
        # Order by severity score (descending) and creation date (descending)
        query = query.order_by(Alert.created_at.desc())
        
        # Apply pagination
        alerts = query.offset(offset).all()
        
        # Filter overdue alerts if requested
        if overdue_only:
            alerts = [alert for alert in alerts if alert.is_overdue]
        
        # Apply limit after filtering
        if limit:
            alerts = alerts[:limit]
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/', methods=['POST'])
def create_alert():
    """
    Create a new alert.
    
    Required fields: title, message, level, alert_type
    Optional fields: studio_id, equipment_id, maintenance_task_id, 
                    priority_score, auto_resolve_at
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['title', 'message', 'level', 'alert_type']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validate alert level
        valid_levels = ['info', 'warning', 'error', 'critical']
        if data['level'] not in valid_levels:
            return jsonify({
                'success': False,
                'error': f'Invalid alert level. Must be one of: {", ".join(valid_levels)}'
            }), 400
        
        # Validate associations if provided
        if data.get('studio_id'):
            studio = Studio.get_by_id(data['studio_id'])
            if not studio:
                return jsonify({
                    'success': False,
                    'error': 'Studio not found'
                }), 404
        
        if data.get('equipment_id'):
            equipment = Equipment.get_by_id(data['equipment_id'])
            if not equipment:
                return jsonify({
                    'success': False,
                    'error': 'Equipment not found'
                }), 404
            
            # If equipment is provided but studio_id is not, use equipment's studio
            if not data.get('studio_id'):
                data['studio_id'] = equipment.studio_id
        
        if data.get('maintenance_task_id'):
            task = MaintenanceTask.get_by_id(data['maintenance_task_id'])
            if not task:
                return jsonify({
                    'success': False,
                    'error': 'Maintenance task not found'
                }), 404
            
            # If task is provided but studio_id/equipment_id are not, use task's associations
            if not data.get('studio_id'):
                data['studio_id'] = task.studio_id
            if not data.get('equipment_id'):
                data['equipment_id'] = task.equipment_id
        
        # Parse auto_resolve_at if provided
        auto_resolve_at = None
        if data.get('auto_resolve_at'):
            try:
                auto_resolve_at = datetime.fromisoformat(data['auto_resolve_at'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid auto_resolve_at format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        # Create new alert
        alert = Alert(
            title=data['title'],
            message=data['message'],
            level=data['level'],
            alert_type=data['alert_type'],
            studio_id=data.get('studio_id'),
            equipment_id=data.get('equipment_id'),
            maintenance_task_id=data.get('maintenance_task_id'),
            priority_score=data.get('priority_score', 0),
            auto_resolve_at=auto_resolve_at
        )
        
        alert.save()
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Alert created successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>', methods=['GET'])
def get_alert(alert_id):
    """
    Get a specific alert by ID.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': alert.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>', methods=['PUT'])
def update_alert(alert_id):
    """
    Update a specific alert.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Update fields if provided
        updatable_fields = [
            'title', 'message', 'level', 'alert_type', 'priority_score'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(alert, field, data[field])
        
        # Handle auto_resolve_at separately
        if 'auto_resolve_at' in data:
            if data['auto_resolve_at']:
                try:
                    alert.auto_resolve_at = datetime.fromisoformat(data['auto_resolve_at'].replace('Z', '+00:00'))
                except ValueError:
                    return jsonify({
                        'success': False,
                        'error': 'Invalid auto_resolve_at format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                    }), 400
            else:
                alert.auto_resolve_at = None
        
        alert.save()
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Alert updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>', methods=['DELETE'])
def delete_alert(alert_id):
    """
    Delete a specific alert.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        alert.delete()
        
        return jsonify({
            'success': True,
            'message': 'Alert deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>/acknowledge', methods=['POST'])
def acknowledge_alert(alert_id):
    """
    Acknowledge an alert.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        if alert.status != 'active':
            return jsonify({
                'success': False,
                'error': f'Cannot acknowledge alert with status: {alert.status}'
            }), 409
        
        data = request.get_json() or {}
        acknowledged_by = data.get('acknowledged_by')
        
        alert.acknowledge(acknowledged_by)
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Alert acknowledged successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>/resolve', methods=['POST'])
def resolve_alert(alert_id):
    """
    Resolve an alert.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        if alert.status == 'resolved':
            return jsonify({
                'success': False,
                'error': 'Alert is already resolved'
            }), 409
        
        data = request.get_json() or {}
        resolved_by = data.get('resolved_by')
        resolution_notes = data.get('resolution_notes')
        
        alert.resolve(resolved_by, resolution_notes)
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Alert resolved successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>/dismiss', methods=['POST'])
def dismiss_alert(alert_id):
    """
    Dismiss an alert.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        if alert.status in ['resolved', 'dismissed']:
            return jsonify({
                'success': False,
                'error': f'Cannot dismiss alert with status: {alert.status}'
            }), 409
        
        alert.dismiss()
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': 'Alert dismissed successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/<int:alert_id>/escalate', methods=['POST'])
def escalate_alert(alert_id):
    """
    Escalate an alert to higher priority.
    """
    try:
        alert = Alert.get_by_id(alert_id)
        
        if not alert:
            return jsonify({
                'success': False,
                'error': 'Alert not found'
            }), 404
        
        if alert.status != 'active':
            return jsonify({
                'success': False,
                'error': f'Cannot escalate alert with status: {alert.status}'
            }), 409
        
        if alert.level == 'critical':
            return jsonify({
                'success': False,
                'error': 'Alert is already at critical level'
            }), 409
        
        old_level = alert.level
        alert.escalate()
        
        return jsonify({
            'success': True,
            'data': alert.to_dict(),
            'message': f'Alert escalated from {old_level} to {alert.level}'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/critical', methods=['GET'])
def get_critical_alerts():
    """
    Get all critical active alerts.
    """
    try:
        alerts = Alert.get_critical_alerts()
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/overdue', methods=['GET'])
def get_overdue_alerts():
    """
    Get alerts that are overdue for response.
    """
    try:
        alerts = Alert.get_overdue_alerts()
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/stats', methods=['GET'])
def get_alert_stats():
    """
    Get alert statistics.
    """
    try:
        studio_id = request.args.get('studio_id', type=int)
        days = request.args.get('days', 30, type=int)
        
        stats = Alert.get_alert_statistics(studio_id, days)
        
        # Additional statistics
        query = Alert.query
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        # Alerts by level
        by_level = {}
        for level in ['info', 'warning', 'error', 'critical']:
            count = query.filter_by(level=level).count()
            by_level[level] = count
        
        # Alerts by status
        by_status = {}
        for status in ['active', 'acknowledged', 'resolved', 'dismissed']:
            count = query.filter_by(status=status).count()
            by_status[status] = count
        
        # Recent alert types
        recent_types = db.session.query(Alert.alert_type, db.func.count(Alert.id))\
            .filter(Alert.created_at >= datetime.utcnow() - timedelta(days=days))\
            .group_by(Alert.alert_type).all()
        
        by_type = {alert_type: count for alert_type, count in recent_types}
        
        stats.update({
            'by_level': by_level,
            'by_status': by_status,
            'by_type': by_type,
            'period_days': days
        })
        
        return jsonify({
            'success': True,
            'data': stats
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/bulk-acknowledge', methods=['POST'])
def bulk_acknowledge_alerts():
    """
    Acknowledge multiple alerts at once.
    """
    try:
        data = request.get_json()
        
        if not data or 'alert_ids' not in data:
            return jsonify({
                'success': False,
                'error': 'alert_ids field is required'
            }), 400
        
        alert_ids = data['alert_ids']
        acknowledged_by = data.get('acknowledged_by')
        
        if not isinstance(alert_ids, list):
            return jsonify({
                'success': False,
                'error': 'alert_ids must be a list'
            }), 400
        
        # Get alerts
        alerts = Alert.query.filter(Alert.id.in_(alert_ids)).all()
        
        if len(alerts) != len(alert_ids):
            return jsonify({
                'success': False,
                'error': 'Some alerts were not found'
            }), 404
        
        # Acknowledge all alerts
        acknowledged_count = 0
        for alert in alerts:
            if alert.status == 'active':
                alert.acknowledge(acknowledged_by)
                acknowledged_count += 1
        
        return jsonify({
            'success': True,
            'message': f'Acknowledged {acknowledged_count} alerts',
            'acknowledged_count': acknowledged_count,
            'total_count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/bulk-resolve', methods=['POST'])
def bulk_resolve_alerts():
    """
    Resolve multiple alerts at once.
    """
    try:
        data = request.get_json()
        
        if not data or 'alert_ids' not in data:
            return jsonify({
                'success': False,
                'error': 'alert_ids field is required'
            }), 400
        
        alert_ids = data['alert_ids']
        resolved_by = data.get('resolved_by')
        resolution_notes = data.get('resolution_notes')
        
        if not isinstance(alert_ids, list):
            return jsonify({
                'success': False,
                'error': 'alert_ids must be a list'
            }), 400
        
        # Get alerts
        alerts = Alert.query.filter(Alert.id.in_(alert_ids)).all()
        
        if len(alerts) != len(alert_ids):
            return jsonify({
                'success': False,
                'error': 'Some alerts were not found'
            }), 404
        
        # Resolve all alerts
        resolved_count = 0
        for alert in alerts:
            if alert.status != 'resolved':
                alert.resolve(resolved_by, resolution_notes)
                resolved_count += 1
        
        return jsonify({
            'success': True,
            'message': f'Resolved {resolved_count} alerts',
            'resolved_count': resolved_count,
            'total_count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/cleanup', methods=['POST'])
def cleanup_old_alerts():
    """
    Clean up old resolved/dismissed alerts.
    """
    try:
        data = request.get_json() or {}
        days = data.get('days', 90)
        
        if not isinstance(days, int) or days < 1:
            return jsonify({
                'success': False,
                'error': 'Days must be a positive integer'
            }), 400
        
        deleted_count = Alert.cleanup_old_alerts(days)
        
        return jsonify({
            'success': True,
            'message': f'Cleaned up {deleted_count} old alerts',
            'deleted_count': deleted_count,
            'days_threshold': days
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/auto-resolve-check', methods=['POST'])
def auto_resolve_check():
    """
    Check and auto-resolve alerts that have passed their auto-resolve time.
    """
    try:
        # Get alerts that should be auto-resolved
        auto_resolve_alerts = Alert.query.filter(
            Alert.auto_resolve_at <= datetime.utcnow(),
            Alert.status == 'active'
        ).all()
        
        resolved_count = 0
        for alert in auto_resolve_alerts:
            alert.auto_resolve_check()
            if alert.status == 'resolved':
                resolved_count += 1
        
        return jsonify({
            'success': True,
            'message': f'Auto-resolved {resolved_count} alerts',
            'resolved_count': resolved_count
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@alerts_bp.route('/search', methods=['GET'])
def search_alerts():
    """
    Search alerts by various criteria.
    """
    try:
        query_param = request.args.get('q', '').strip()
        
        if not query_param:
            return jsonify({
                'success': False,
                'error': 'Search query parameter "q" is required'
            }), 400
        
        # Search in title, message, and resolution notes
        alerts = Alert.query.filter(
            db.or_(
                Alert.title.ilike(f'%{query_param}%'),
                Alert.message.ilike(f'%{query_param}%'),
                Alert.resolution_notes.ilike(f'%{query_param}%'),
                Alert.alert_type.ilike(f'%{query_param}%')
            )
        ).all()
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'count': len(alerts),
            'query': query_param
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

