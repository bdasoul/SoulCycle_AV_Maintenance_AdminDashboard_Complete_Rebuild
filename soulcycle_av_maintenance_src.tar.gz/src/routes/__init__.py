"""
Routes package for SoulCycle AV Maintenance System.
Contains all Flask blueprints for API endpoints.
"""

from .studios import studios_bp
from .equipment import equipment_bp
from .maintenance import maintenance_bp
from .alerts import alerts_bp
from .reports import reports_bp

__all__ = [
    'studios_bp',
    'equipment_bp',
    'maintenance_bp',
    'alerts_bp',
    'reports_bp'
]

