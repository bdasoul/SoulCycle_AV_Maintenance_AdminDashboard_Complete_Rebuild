"""
Studios API routes for SoulCycle AV Maintenance System.
"""

from flask import Blueprint, request, jsonify
from src.models import db, Studio
from datetime import datetime

studios_bp = Blueprint('studios', __name__)


@studios_bp.route('/', methods=['GET'])
def get_studios():
    """
    Get all studios with optional filtering.
    
    Query Parameters:
        status: Filter by status (active, inactive)
        location: Filter by location (partial match)
        limit: Limit number of results
        offset: Offset for pagination
    """
    try:
        # Get query parameters
        status = request.args.get('status')
        location = request.args.get('location')
        limit = request.args.get('limit', type=int)
        offset = request.args.get('offset', type=int, default=0)
        
        # Build query
        query = Studio.query
        
        if status:
            query = query.filter_by(status=status)
        
        if location:
            query = query.filter(Studio.location.ilike(f'%{location}%'))
        
        # Apply pagination
        if limit:
            query = query.offset(offset).limit(limit)
        
        studios = query.all()
        
        return jsonify({
            'success': True,
            'data': [studio.to_dict() for studio in studios],
            'count': len(studios)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/', methods=['POST'])
def create_studio():
    """
    Create a new studio.
    
    Required fields: name, location
    Optional fields: address, city, state, zip_code, phone, capacity, 
                    classes_per_day, operating_hours, manager_name, 
                    manager_email, manager_phone
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['name', 'location']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Check if studio with same name already exists
        existing_studio = Studio.query.filter_by(name=data['name']).first()
        if existing_studio:
            return jsonify({
                'success': False,
                'error': 'Studio with this name already exists'
            }), 409
        
        # Create new studio
        studio = Studio(
            name=data['name'],
            location=data['location'],
            address=data.get('address'),
            city=data.get('city'),
            state=data.get('state'),
            zip_code=data.get('zip_code'),
            phone=data.get('phone'),
            capacity=data.get('capacity'),
            classes_per_day=data.get('classes_per_day'),
            operating_hours=data.get('operating_hours'),
            manager_name=data.get('manager_name'),
            manager_email=data.get('manager_email'),
            manager_phone=data.get('manager_phone'),
            status=data.get('status', 'active')
        )
        
        studio.save()
        
        return jsonify({
            'success': True,
            'data': studio.to_dict(),
            'message': 'Studio created successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>', methods=['GET'])
def get_studio(studio_id):
    """
    Get a specific studio by ID.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': studio.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>', methods=['PUT'])
def update_studio(studio_id):
    """
    Update a specific studio.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Update fields if provided
        updatable_fields = [
            'name', 'location', 'address', 'city', 'state', 'zip_code',
            'phone', 'capacity', 'classes_per_day', 'operating_hours',
            'manager_name', 'manager_email', 'manager_phone', 'status'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(studio, field, data[field])
        
        studio.save()
        
        return jsonify({
            'success': True,
            'data': studio.to_dict(),
            'message': 'Studio updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>', methods=['DELETE'])
def delete_studio(studio_id):
    """
    Delete a specific studio.
    Note: This will also delete all associated equipment, tasks, and alerts.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        # Check if studio has equipment
        if studio.equipment.count() > 0:
            return jsonify({
                'success': False,
                'error': 'Cannot delete studio with associated equipment. Remove equipment first.'
            }), 409
        
        studio.delete()
        
        return jsonify({
            'success': True,
            'message': 'Studio deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>/equipment', methods=['GET'])
def get_studio_equipment(studio_id):
    """
    Get all equipment for a specific studio.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        equipment_type = request.args.get('type')
        
        if equipment_type:
            equipment = studio.get_equipment_by_type(equipment_type)
        else:
            equipment = studio.equipment.all()
        
        return jsonify({
            'success': True,
            'data': [eq.to_dict() for eq in equipment],
            'count': len(equipment)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>/maintenance', methods=['GET'])
def get_studio_maintenance(studio_id):
    """
    Get maintenance tasks for a specific studio.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        status = request.args.get('status')
        overdue_only = request.args.get('overdue', 'false').lower() == 'true'
        
        if overdue_only:
            tasks = studio.get_overdue_maintenance()
        elif status:
            tasks = studio.maintenance_tasks.filter_by(status=status).all()
        else:
            tasks = studio.maintenance_tasks.all()
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>/alerts', methods=['GET'])
def get_studio_alerts(studio_id):
    """
    Get alerts for a specific studio.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        level = request.args.get('level')
        status = request.args.get('status', 'active')
        critical_only = request.args.get('critical', 'false').lower() == 'true'
        
        if critical_only:
            alerts = studio.get_critical_alerts()
        elif level:
            alerts = studio.alerts.filter_by(level=level, status=status).all()
        else:
            alerts = studio.alerts.filter_by(status=status).all()
        
        return jsonify({
            'success': True,
            'data': [alert.to_dict() for alert in alerts],
            'count': len(alerts)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/<int:studio_id>/dashboard', methods=['GET'])
def get_studio_dashboard(studio_id):
    """
    Get dashboard data for a specific studio.
    """
    try:
        studio = Studio.get_by_id(studio_id)
        
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        # Get dashboard statistics
        total_equipment = studio.equipment.count()
        critical_equipment = studio.equipment.filter_by(is_critical=True).count()
        active_alerts = studio.alerts.filter_by(status='active').count()
        critical_alerts = studio.get_critical_alerts()
        overdue_maintenance = studio.get_overdue_maintenance()
        
        # Equipment by type
        equipment_by_type = {}
        for equipment in studio.equipment.all():
            if equipment.type not in equipment_by_type:
                equipment_by_type[equipment.type] = 0
            equipment_by_type[equipment.type] += 1
        
        dashboard_data = {
            'studio_info': studio.to_dict(),
            'statistics': {
                'total_equipment': total_equipment,
                'critical_equipment': critical_equipment,
                'active_alerts': active_alerts,
                'critical_alerts': len(critical_alerts),
                'overdue_maintenance': len(overdue_maintenance)
            },
            'equipment_by_type': equipment_by_type,
            'recent_alerts': [alert.to_dict() for alert in critical_alerts[:5]],
            'overdue_tasks': [task.to_dict() for task in overdue_maintenance[:5]]
        }
        
        return jsonify({
            'success': True,
            'data': dashboard_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/search', methods=['GET'])
def search_studios():
    """
    Search studios by various criteria.
    """
    try:
        query_param = request.args.get('q', '').strip()
        
        if not query_param:
            return jsonify({
                'success': False,
                'error': 'Search query parameter "q" is required'
            }), 400
        
        # Search in name, location, city, and manager name
        studios = Studio.query.filter(
            db.or_(
                Studio.name.ilike(f'%{query_param}%'),
                Studio.location.ilike(f'%{query_param}%'),
                Studio.city.ilike(f'%{query_param}%'),
                Studio.manager_name.ilike(f'%{query_param}%')
            )
        ).all()
        
        return jsonify({
            'success': True,
            'data': [studio.to_dict() for studio in studios],
            'count': len(studios),
            'query': query_param
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@studios_bp.route('/stats', methods=['GET'])
def get_studios_stats():
    """
    Get overall statistics for all studios.
    """
    try:
        total_studios = Studio.query.count()
        active_studios = Studio.query.filter_by(status='active').count()
        
        # Studios by state
        studios_by_state = db.session.query(
            Studio.state, 
            db.func.count(Studio.id)
        ).group_by(Studio.state).all()
        
        state_distribution = {state: count for state, count in studios_by_state if state}
        
        return jsonify({
            'success': True,
            'data': {
                'total_studios': total_studios,
                'active_studios': active_studios,
                'inactive_studios': total_studios - active_studios,
                'studios_by_state': state_distribution
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

