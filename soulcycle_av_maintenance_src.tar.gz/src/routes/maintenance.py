"""
Maintenance API routes for SoulCycle AV Maintenance System.
"""

from flask import Blueprint, request, jsonify
from src.models import db, MaintenanceTask, Equipment, Studio
from datetime import datetime, timedelta

maintenance_bp = Blueprint('maintenance', __name__)


@maintenance_bp.route('/', methods=['GET'])
def get_maintenance_tasks():
    """
    Get all maintenance tasks with optional filtering.
    
    Query Parameters:
        studio_id: Filter by studio ID
        equipment_id: Filter by equipment ID
        status: Filter by status (pending, scheduled, in_progress, completed, cancelled)
        priority: Filter by priority (low, medium, high, critical)
        task_type: Filter by task type (preventive, corrective, emergency)
        overdue: Filter overdue tasks only (true/false)
        upcoming: Filter upcoming tasks (days parameter)
        technician: Filter by assigned technician
        limit: Limit number of results
        offset: Offset for pagination
    """
    try:
        # Get query parameters
        studio_id = request.args.get('studio_id', type=int)
        equipment_id = request.args.get('equipment_id', type=int)
        status = request.args.get('status')
        priority = request.args.get('priority')
        task_type = request.args.get('task_type')
        overdue_only = request.args.get('overdue', 'false').lower() == 'true'
        upcoming_days = request.args.get('upcoming', type=int)
        technician = request.args.get('technician')
        limit = request.args.get('limit', type=int)
        offset = request.args.get('offset', type=int, default=0)
        
        # Build query
        query = MaintenanceTask.query
        
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        if equipment_id:
            query = query.filter_by(equipment_id=equipment_id)
        
        if status:
            query = query.filter_by(status=status)
        
        if priority:
            query = query.filter_by(priority=priority)
        
        if task_type:
            query = query.filter_by(task_type=task_type)
        
        if technician:
            query = query.filter_by(assigned_technician=technician)
        
        if overdue_only:
            query = query.filter(
                MaintenanceTask.due_date < datetime.utcnow(),
                MaintenanceTask.status.notin_(['completed', 'cancelled'])
            )
        
        if upcoming_days:
            cutoff_date = datetime.utcnow() + timedelta(days=upcoming_days)
            query = query.filter(
                MaintenanceTask.due_date <= cutoff_date,
                MaintenanceTask.due_date >= datetime.utcnow(),
                MaintenanceTask.status == 'pending'
            )
        
        # Apply pagination
        tasks = query.offset(offset).all()
        
        if limit:
            tasks = tasks[:limit]
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/', methods=['POST'])
def create_maintenance_task():
    """
    Create a new maintenance task.
    
    Required fields: title, studio_id, equipment_id, task_type, due_date
    Optional fields: description, priority, estimated_duration, assigned_technician,
                    estimated_cost, safety_requirements, required_tools, required_parts
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['title', 'studio_id', 'equipment_id', 'task_type', 'due_date']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validate studio exists
        studio = Studio.get_by_id(data['studio_id'])
        if not studio:
            return jsonify({
                'success': False,
                'error': 'Studio not found'
            }), 404
        
        # Validate equipment exists
        equipment = Equipment.get_by_id(data['equipment_id'])
        if not equipment:
            return jsonify({
                'success': False,
                'error': 'Equipment not found'
            }), 404
        
        # Validate equipment belongs to studio
        if equipment.studio_id != data['studio_id']:
            return jsonify({
                'success': False,
                'error': 'Equipment does not belong to the specified studio'
            }), 400
        
        # Validate task type
        valid_types = ['preventive', 'corrective', 'emergency', 'inspection', 'calibration']
        if data['task_type'] not in valid_types:
            return jsonify({
                'success': False,
                'error': f'Invalid task type. Must be one of: {", ".join(valid_types)}'
            }), 400
        
        # Validate priority
        valid_priorities = ['low', 'medium', 'high', 'critical']
        priority = data.get('priority', 'medium')
        if priority not in valid_priorities:
            return jsonify({
                'success': False,
                'error': f'Invalid priority. Must be one of: {", ".join(valid_priorities)}'
            }), 400
        
        # Parse due date
        try:
            due_date = datetime.fromisoformat(data['due_date'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({
                'success': False,
                'error': 'Invalid due_date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
            }), 400
        
        # Parse scheduled date if provided
        scheduled_date = None
        if data.get('scheduled_date'):
            try:
                scheduled_date = datetime.fromisoformat(data['scheduled_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid scheduled_date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        # Create new maintenance task
        task = MaintenanceTask(
            title=data['title'],
            description=data.get('description'),
            task_type=data['task_type'],
            priority=priority,
            studio_id=data['studio_id'],
            equipment_id=data['equipment_id'],
            due_date=due_date,
            scheduled_date=scheduled_date,
            estimated_duration=data.get('estimated_duration'),
            assigned_technician=data.get('assigned_technician'),
            estimated_cost=data.get('estimated_cost'),
            safety_requirements=data.get('safety_requirements'),
            required_tools=data.get('required_tools'),
            required_parts=data.get('required_parts'),
            status=data.get('status', 'pending')
        )
        
        task.save()
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': 'Maintenance task created successfully'
        }), 201
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>', methods=['GET'])
def get_maintenance_task(task_id):
    """
    Get a specific maintenance task by ID.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': task.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>', methods=['PUT'])
def update_maintenance_task(task_id):
    """
    Update a specific maintenance task.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Update fields if provided
        updatable_fields = [
            'title', 'description', 'task_type', 'priority', 'estimated_duration',
            'assigned_technician', 'estimated_cost', 'safety_requirements',
            'required_tools', 'required_parts', 'technician_notes'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(task, field, data[field])
        
        # Handle date fields
        if 'due_date' in data:
            try:
                task.due_date = datetime.fromisoformat(data['due_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid due_date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        if 'scheduled_date' in data:
            try:
                task.scheduled_date = datetime.fromisoformat(data['scheduled_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    'success': False,
                    'error': 'Invalid scheduled_date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)'
                }), 400
        
        task.save()
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': 'Maintenance task updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>', methods=['DELETE'])
def delete_maintenance_task(task_id):
    """
    Delete a specific maintenance task.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        # Don't allow deletion of completed tasks
        if task.status == 'completed':
            return jsonify({
                'success': False,
                'error': 'Cannot delete completed maintenance tasks'
            }), 409
        
        task.delete()
        
        return jsonify({
            'success': True,
            'message': 'Maintenance task deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>/start', methods=['POST'])
def start_maintenance_task(task_id):
    """
    Start a maintenance task.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        if task.status != 'pending':
            return jsonify({
                'success': False,
                'error': f'Cannot start task with status: {task.status}'
            }), 409
        
        data = request.get_json() or {}
        technician_name = data.get('technician_name')
        
        task.start_task(technician_name)
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': 'Maintenance task started successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>/complete', methods=['POST'])
def complete_maintenance_task(task_id):
    """
    Complete a maintenance task.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        if task.status not in ['pending', 'in_progress']:
            return jsonify({
                'success': False,
                'error': f'Cannot complete task with status: {task.status}'
            }), 409
        
        data = request.get_json() or {}
        
        completion_notes = data.get('completion_notes')
        actual_duration = data.get('actual_duration')
        actual_cost = data.get('actual_cost')
        parts_cost = data.get('parts_cost')
        labor_cost = data.get('labor_cost')
        
        # Update cost fields if provided
        if actual_cost:
            task.actual_cost = actual_cost
        if parts_cost:
            task.parts_cost = parts_cost
        if labor_cost:
            task.labor_cost = labor_cost
        
        task.complete_task(completion_notes, actual_duration, actual_cost)
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': 'Maintenance task completed successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>/cancel', methods=['POST'])
def cancel_maintenance_task(task_id):
    """
    Cancel a maintenance task.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        if task.status in ['completed', 'cancelled']:
            return jsonify({
                'success': False,
                'error': f'Cannot cancel task with status: {task.status}'
            }), 409
        
        data = request.get_json() or {}
        reason = data.get('reason')
        
        task.cancel_task(reason)
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': 'Maintenance task cancelled successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/<int:task_id>/escalate', methods=['POST'])
def escalate_maintenance_task(task_id):
    """
    Escalate a maintenance task priority.
    """
    try:
        task = MaintenanceTask.get_by_id(task_id)
        
        if not task:
            return jsonify({
                'success': False,
                'error': 'Maintenance task not found'
            }), 404
        
        if task.status in ['completed', 'cancelled']:
            return jsonify({
                'success': False,
                'error': f'Cannot escalate task with status: {task.status}'
            }), 409
        
        old_priority = task.priority
        task.escalate_priority()
        
        return jsonify({
            'success': True,
            'data': task.to_dict(),
            'message': f'Task priority escalated from {old_priority} to {task.priority}'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/overdue', methods=['GET'])
def get_overdue_tasks():
    """
    Get all overdue maintenance tasks.
    """
    try:
        tasks = MaintenanceTask.get_overdue_tasks()
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/upcoming', methods=['GET'])
def get_upcoming_tasks():
    """
    Get upcoming maintenance tasks.
    """
    try:
        days = request.args.get('days', 7, type=int)
        tasks = MaintenanceTask.get_upcoming_tasks(days)
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks),
            'days_ahead': days
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/by-technician/<technician_name>', methods=['GET'])
def get_tasks_by_technician(technician_name):
    """
    Get tasks assigned to a specific technician.
    """
    try:
        tasks = MaintenanceTask.get_by_technician(technician_name)
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks),
            'technician': technician_name
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/by-priority/<priority>', methods=['GET'])
def get_tasks_by_priority(priority):
    """
    Get tasks by priority level.
    """
    try:
        valid_priorities = ['low', 'medium', 'high', 'critical']
        if priority not in valid_priorities:
            return jsonify({
                'success': False,
                'error': f'Invalid priority. Must be one of: {", ".join(valid_priorities)}'
            }), 400
        
        tasks = MaintenanceTask.get_by_priority(priority)
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks),
            'priority': priority
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/stats', methods=['GET'])
def get_maintenance_stats():
    """
    Get maintenance statistics.
    """
    try:
        studio_id = request.args.get('studio_id', type=int)
        days = request.args.get('days', 30, type=int)
        
        start_date = datetime.utcnow() - timedelta(days=days)
        end_date = datetime.utcnow()
        
        stats = MaintenanceTask.get_completion_stats(studio_id, start_date, end_date)
        
        # Additional statistics
        query = MaintenanceTask.query
        if studio_id:
            query = query.filter_by(studio_id=studio_id)
        
        # Tasks by status
        by_status = {}
        for status in ['pending', 'scheduled', 'in_progress', 'completed', 'cancelled']:
            count = query.filter_by(status=status).count()
            by_status[status] = count
        
        # Tasks by priority
        by_priority = {}
        for priority in ['low', 'medium', 'high', 'critical']:
            count = query.filter_by(priority=priority).count()
            by_priority[priority] = count
        
        # Tasks by type
        by_type = {}
        for task_type in ['preventive', 'corrective', 'emergency', 'inspection', 'calibration']:
            count = query.filter_by(task_type=task_type).count()
            by_type[task_type] = count
        
        stats.update({
            'by_status': by_status,
            'by_priority': by_priority,
            'by_type': by_type,
            'period_days': days
        })
        
        return jsonify({
            'success': True,
            'data': stats
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/technicians', methods=['GET'])
def get_technicians():
    """
    Get list of all technicians who have been assigned tasks.
    """
    try:
        # Get unique technician names from maintenance tasks
        technicians = db.session.query(MaintenanceTask.assigned_technician)\
            .filter(MaintenanceTask.assigned_technician.isnot(None))\
            .distinct().all()
        
        technician_list = [tech[0] for tech in technicians if tech[0]]
        
        return jsonify({
            'success': True,
            'data': technician_list,
            'count': len(technician_list)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@maintenance_bp.route('/search', methods=['GET'])
def search_maintenance_tasks():
    """
    Search maintenance tasks by various criteria.
    """
    try:
        query_param = request.args.get('q', '').strip()
        
        if not query_param:
            return jsonify({
                'success': False,
                'error': 'Search query parameter "q" is required'
            }), 400
        
        # Search in title, description, and technician notes
        tasks = MaintenanceTask.query.filter(
            db.or_(
                MaintenanceTask.title.ilike(f'%{query_param}%'),
                MaintenanceTask.description.ilike(f'%{query_param}%'),
                MaintenanceTask.technician_notes.ilike(f'%{query_param}%'),
                MaintenanceTask.assigned_technician.ilike(f'%{query_param}%')
            )
        ).all()
        
        return jsonify({
            'success': True,
            'data': [task.to_dict() for task in tasks],
            'count': len(tasks),
            'query': query_param
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

